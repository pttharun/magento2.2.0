<?php
/**
* Copyright © 2016 SW-THEMES. All rights reserved.
*/

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::THEME,
    'frontend/Magento/custom',
    __DIR__
);
