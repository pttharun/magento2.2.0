requirejs(['jquery',
    'owl.carousel/owl.carousel.min',
    'mage/apply/main',
    "jquery/jquery.cookie",
    "kinetic"
], function ($) {
    
    
    jQuery(document).ready(function ($) {
        
    });
    
});